export const navLinks = [
  { id: 1, role: 1, link: "/chat", title: "chat", icon: "bx bx-message-dots" },
  {
    id: 2,
    role: 1,
    link: "/hotels",
    title: "hotels",
    icon: "bx bx-hotel",
  },
  {
    id: 3,
    role: 1,
    link: "/emploee",
    title: "emploee",
    icon: "bx bx-street-view",
  },
  {
    id: 4,
    role: 1,
    link: "/social",
    title: "social",
    icon: "bx bx-network-chart",
  },
  {
    id: 5,
    role: 1,
    link: "/tour",
    title: "tour",
    icon: "bx bx-briefcase-alt-2",
  },
];
