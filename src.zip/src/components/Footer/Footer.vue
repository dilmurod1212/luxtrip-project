<template>
  <div>
    <h1>Footer</h1>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>