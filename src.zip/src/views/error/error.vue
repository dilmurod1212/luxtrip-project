<template>
  <div>
    <h1>error</h1>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>